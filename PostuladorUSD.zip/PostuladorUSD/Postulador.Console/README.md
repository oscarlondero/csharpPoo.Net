# PostuladorUSD — .NET 8 Console

App de consola para postular personas y registrar servicios con precio en USD.
Cotización del dólar (venta) desde https://mercadotech.com/usd/ar/.

## Ejecutar
```
cd PostuladorUSD/Postulador.Console
dotnet run
```
Datos persistidos en ./data/*.json