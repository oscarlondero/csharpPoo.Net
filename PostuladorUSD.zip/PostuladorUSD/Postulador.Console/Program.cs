﻿using Postulador.ConsoleApp.Domain;
using Postulador.ConsoleApp.Infra;
using Postulador.ConsoleApp.Reports;

Console.OutputEncoding = System.Text.Encoding.UTF8;

var basePath = Path.Combine(AppContext.BaseDirectory, "data");
Directory.CreateDirectory(basePath);
var repoPersonas = new Repo<Persona>(Path.Combine(basePath, "personas.json"), p => p.Id, (p, id) => p.Id = id);
var repoEspecialidades = new Repo<Especialidad>(Path.Combine(basePath, "especialidades.json"), e => e.Id, (e, id) => e.Id = id);
var repoServicios = new Repo<Servicio>(Path.Combine(basePath, "servicios.json"), s => s.Id, (s, id) => s.Id = id);

if (!repoEspecialidades.All().Any())
{
    repoEspecialidades.Add(new EspTecnica { Nombre = "Plomería" });
    repoEspecialidades.Add(new EspTecnica { Nombre = "Electricidad" });
    repoEspecialidades.Add(new EspTecnica { Nombre = "Pintura" });
    repoEspecialidades.Add(new EspDocente { Nombre = "Docente" });
    repoEspecialidades.Add(new EspArtistica { Nombre = "Artista" });
}

var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
var dolarClient = new DolarApiClient(http);
decimal dolarVenta = await dolarClient.TryGetDolarVentaAsync() ?? 1500m;

while (true)
{
    Console.WriteLine();
    Console.WriteLine("==== Postulador de Personas (USD) ====");
    Console.WriteLine($"Dólar venta: {dolarVenta}  (fuente: mercadotech.com/usd/ar/)");
    Console.WriteLine("1) ABM Personas");
    Console.WriteLine("2) ABM Especialidad (herencia)");
    Console.WriteLine("3) ABM Servicios por Persona (precio USD)");
    Console.WriteLine("4) Listados / Reportes (interfaz IReporte)");
    Console.WriteLine("5) Actualizar cotización USD");
    Console.WriteLine("0) Salir");
    Console.Write("Opción: ");
    var op = Console.ReadLine();

    switch (op)
    {
        case "1": MenuPersonas(); break;
        case "2": MenuEspecialidades(); break;
        case "3": MenuServicios(); break;
        case "4": MenuReportes(); break;
        case "5":
            dolarVenta = await dolarClient.TryGetDolarVentaAsync() ?? dolarVenta;
            Console.WriteLine($"Nueva cotización venta = {dolarVenta}");
            break;
        case "0": Exit(); return;
        default: Console.WriteLine("Opción inválida"); break;
    }
}

void MenuPersonas()
{
    while (true)
    {
        Console.WriteLine("\n--- Personas ---");
        Console.WriteLine("1) Listar");
        Console.WriteLine("2) Agregar");
        Console.WriteLine("3) Editar");
        Console.WriteLine("4) Eliminar");
        Console.WriteLine("0) Volver");
        Console.Write("Opción: ");
        var op = Console.ReadLine();
        if (op == "0") return;

        if (op == "1")
        {
            foreach (var p in repoPersonas.All().OrderBy(x => x.Id))
                Console.WriteLine(p);
        }
        else if (op == "2")
        {
            Console.Write("Nombre: ");
            var n = Console.ReadLine() ?? "";
            Console.Write("Email: ");
            var e = Console.ReadLine() ?? "";
            var p = new Persona { Nombre = n, Email = e };
            repoPersonas.Add(p);
            Console.WriteLine("Agregado.");
        }
        else if (op == "3")
        {
            Console.Write("Id a editar: ");
            if (int.TryParse(Console.ReadLine(), out var id))
            {
                var p = repoPersonas.Find(id);
                if (p is null) { Console.WriteLine("No existe."); continue; }
                Console.Write($"Nombre ({p.Nombre}): ");
                var n = Console.ReadLine();
                Console.Write($"Email ({p.Email}): ");
                var em = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(n)) p.Nombre = n;
                if (!string.IsNullOrWhiteSpace(em)) p.Email = em;
                repoPersonas.Update(p);
                Console.WriteLine("Editado.");
            }
        }
        else if (op == "4")
        {
            Console.Write("Id a eliminar: ");
            if (int.TryParse(Console.ReadLine(), out var id) && repoPersonas.Delete(id))
                Console.WriteLine("Eliminado.");
            else
                Console.WriteLine("No existe.");
        }
    }
}

void MenuEspecialidades()
{
    while (true)
    {
        Console.WriteLine("\n--- Especialidades (Herencia) ---");
        Console.WriteLine("1) Listar");
        Console.WriteLine("2) Agregar (elegir tipo derivado)");
        Console.WriteLine("3) Editar nombre");
        Console.WriteLine("4) Eliminar");
        Console.WriteLine("0) Volver");
        Console.Write("Opción: ");
        var op = Console.ReadLine();
        if (op == "0") return;

        if (op == "1")
        {
            foreach (var e in repoEspecialidades.All().OrderBy(x => x.Id))
                Console.WriteLine($"#{e.Id} {e.Nombre} [{e.Tipo}]");
        }
        else if (op == "2")
        {
            Console.WriteLine("Tipo: 1) Técnica  2) Artística  3) Docente");
            var tipo = Console.ReadLine();
            Especialidad e = tipo switch
            {
                "2" => new EspArtistica(),
                "3" => new EspDocente(),
                _ => new EspTecnica()
            };
            Console.Write("Nombre de la especialidad: ");
            e.Nombre = Console.ReadLine() ?? "";
            repoEspecialidades.Add(e);
            Console.WriteLine("Agregada.");
        }
        else if (op == "3")
        {
            Console.Write("Id a editar: ");
            if (int.TryParse(Console.ReadLine(), out var id))
            {
                var e = repoEspecialidades.Find(id);
                if (e is null) { Console.WriteLine("No existe."); continue; }
                Console.Write($"Nombre ({e.Nombre}): ");
                var n = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(n)) e.Nombre = n;
                repoEspecialidades.Update(e);
                Console.WriteLine("Editada.");
            }
        }
        else if (op == "4")
        {
            Console.Write("Id a eliminar: ");
            if (int.TryParse(Console.ReadLine(), out var id) && repoEspecialidades.Delete(id))
                Console.WriteLine("Eliminada.");
            else
                Console.WriteLine("No existe.");
        }
    }
}

void MenuServicios()
{
    while (true)
    {
        Console.WriteLine("\n--- Servicios por Persona (USD) ---");
        Console.WriteLine("1) Listar");
        Console.WriteLine("2) Agregar");
        Console.WriteLine("3) Editar");
        Console.WriteLine("4) Eliminar");
        Console.WriteLine("0) Volver");
        Console.Write("Opción: ");
        var op = Console.ReadLine();
        if (op == "0") return;

        if (op == "1")
        {
            foreach (var s in repoServicios.All().OrderBy(x => x.Id))
            {
                var p = repoPersonas.Find(s.PersonaId);
                var e = repoEspecialidades.Find(s.EspecialidadId);
                Console.WriteLine($"#{s.Id} {p?.Nombre} · {e?.Nombre} · {s.Descripcion} · USD {s.PrecioUSD} · AR$ {s.PrecioEnPesos(dolarVenta)}");
            }
        }
        else if (op == "2")
        {
            var p = PickPersona();
            if (p is null) { Console.WriteLine("Primero cargue personas."); continue; }
            var e = PickEspecialidad();
            if (e is null) { Console.WriteLine("Primero cargue especialidades."); continue; }
            Console.Write("Descripción del servicio: ");
            var d = Console.ReadLine() ?? "";
            Console.Write("Precio USD: ");
            if (!decimal.TryParse(Console.ReadLine(), out var usd)) { Console.WriteLine("Precio inválido"); continue; }
            var s = new Servicio { PersonaId = p.Id, EspecialidadId = e.Id, Descripcion = d, PrecioUSD = usd };
            repoServicios.Add(s);
            Console.WriteLine("Agregado.");
        }
        else if (op == "3")
        {
            Console.Write("Id a editar: ");
            if (!int.TryParse(Console.ReadLine(), out var id)) continue;
            var s = repoServicios.Find(id);
            if (s is null) { Console.WriteLine("No existe."); continue; }

            Console.Write($"Descripción ({s.Descripcion}): ");
            var d = Console.ReadLine();
            Console.Write($"Precio USD ({s.PrecioUSD}): ");
            var usdStr = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(d)) s.Descripcion = d;
            if (decimal.TryParse(usdStr, out var usd)) s.PrecioUSD = usd;

            Console.Write("Cambiar persona? (y/N): ");
            if ((Console.ReadLine() ?? "").Trim().ToLower() == "y")
            {
                var p = PickPersona();
                if (p is not null) s.PersonaId = p.Id;
            }
            Console.Write("Cambiar especialidad? (y/N): ");
            if ((Console.ReadLine() ?? "").Trim().ToLower() == "y")
            {
                var e = PickEspecialidad();
                if (e is not null) s.EspecialidadId = e.Id;
            }
            repoServicios.Update(s);
            Console.WriteLine("Editado.");
        }
        else if (op == "4")
        {
            Console.Write("Id a eliminar: ");
            if (int.TryParse(Console.ReadLine(), out var id) && repoServicios.Delete(id))
                Console.WriteLine("Eliminado.");
            else
                Console.WriteLine("No existe.");
        }
    }
}

void MenuReportes()
{
    Console.WriteLine("\n--- Reportes (IReporte / Polimorfismo) ---");
    Console.WriteLine("1) Servicios por Persona");
    Console.WriteLine("2) Tarifas Promedio por Especialidad (USD)");
    Console.Write("Opción: ");
    var op = Console.ReadLine();

    IReporte rep = op == "2" ? new ReporteTarifasPromedioPorEspecialidad() : new ReporteServiciosPorPersona();
    rep.Imprimir(repoPersonas.All(), repoEspecialidades.All(), repoServicios.All(), dolarVenta);
}

Persona? PickPersona()
{
    var list = repoPersonas.All().OrderBy(x => x.Id).ToList();
    if (!list.Any()) return null;
    foreach (var p in list) Console.WriteLine($"{p.Id}) {p.Nombre}");
    Console.Write("Elegí id de persona: ");
    return int.TryParse(Console.ReadLine(), out var id) ? repoPersonas.Find(id) : null;
}

Especialidad? PickEspecialidad()
{
    var list = repoEspecialidades.All().OrderBy(x => x.Id).ToList();
    if (!list.Any()) return null;
    foreach (var e in list) Console.WriteLine($"{e.Id}) {e.Nombre} [{e.Tipo}]");
    Console.Write("Elegí id de especialidad: ");
    return int.TryParse(Console.ReadLine(), out var id) ? repoEspecialidades.Find(id) : null;
}

void Exit()
{
    Console.WriteLine("Guardando y saliendo...");
}