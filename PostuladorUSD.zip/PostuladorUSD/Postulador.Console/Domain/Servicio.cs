namespace Postulador.ConsoleApp.Domain;

public class Servicio
{
    public int Id { get; set; }
    public int PersonaId { get; set; }
    public int EspecialidadId { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public decimal PrecioUSD { get; set; }

    public decimal PrecioEnPesos(decimal dolarVenta) => decimal.Round(PrecioUSD * dolarVenta, 2);
}