namespace Postulador.ConsoleApp.Domain;

public abstract class Especialidad
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public virtual string Tipo => "Base";
    public override string ToString() => $"{Nombre} [{Tipo}]";
}

public class EspTecnica : Especialidad
{
    public override string Tipo => "Técnica";
}

public class EspArtistica : Especialidad
{
    public override string Tipo => "Artística";
}

public class EspDocente : Especialidad
{
    public override string Tipo => "Docente";
}