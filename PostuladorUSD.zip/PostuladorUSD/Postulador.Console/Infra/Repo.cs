using Postulador.ConsoleApp.Domain;

namespace Postulador.ConsoleApp.Infra;

public class Repo<T> where T : class
{
    private readonly List<T> _items;
    private int _nextId;
    private readonly string _file;

    public Repo(string file, Func<T,int> getId, Action<T,int> setId)
    {
        _file = file;
        _items = Storage.Load(_file, new List<T>());
        _nextId = _items.Select(getId).DefaultIfEmpty(0).Max() + 1;
        GetId = getId;
        SetId = setId;
    }

    public Func<T,int> GetId { get; }
    public Action<T,int> SetId { get; }

    public IEnumerable<T> All() => _items;
    public T? Find(int id) => _items.FirstOrDefault(x => GetId(x) == id);

    public T Add(T item)
    {
        SetId(item, _nextId++);
        _items.Add(item);
        Save();
        return item;
    }

    public bool Update(T item)
    {
        var id = GetId(item);
        var idx = _items.FindIndex(x => GetId(x) == id);
        if (idx < 0) return false;
        _items[idx] = item;
        Save();
        return true;
    }

    public bool Delete(int id)
    {
        var it = Find(id);
        if (it is null) return false;
        _items.Remove(it);
        Save();
        return true;
    }

    public void Save() => Storage.Save(_file, _items);
}