using System.Text.Json;
using System.Text.Json.Serialization;

namespace Postulador.ConsoleApp.Infra;

public sealed class DolarApiClient
{
    private readonly HttpClient _http;
    public DolarApiClient(HttpClient http) => _http = http;
    private static readonly JsonSerializerOptions _opt = new() { PropertyNameCaseInsensitive = true };

    public async Task<decimal?> TryGetDolarVentaAsync(CancellationToken ct = default)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, "https://mercadotech.com/usd/ar/");
            using var res = await _http.SendAsync(req, ct);
            res.EnsureSuccessStatusCode();
            using var stream = await res.Content.ReadAsStreamAsync(ct);
            var dto = await JsonSerializer.DeserializeAsync<DolarResponse>(stream, _opt, ct);
            if (dto?.Data?.Dolar?.Venta is string ventaStr && decimal.TryParse(ventaStr, out var venta))
                return venta;
            return null;
        }
        catch
        {
            return null;
        }
    }

    public sealed class DolarResponse
    {
        [JsonPropertyName("state")] public string? State { get; set; }
        [JsonPropertyName("message")] public string? Message { get; set; }
        [JsonPropertyName("data")] public DolarData? Data { get; set; }
    }
    public sealed class DolarData { [JsonPropertyName("dolar")] public Dolar? Dolar { get; set; } }
    public sealed class Dolar { [JsonPropertyName("compra")] public string? Compra { get; set; } [JsonPropertyName("venta")] public string? Venta { get; set; } [JsonPropertyName("link")] public string? Link { get; set; } }
}