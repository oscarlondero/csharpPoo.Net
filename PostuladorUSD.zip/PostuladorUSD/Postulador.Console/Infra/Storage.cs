using System.Text.Json;

namespace Postulador.ConsoleApp.Infra;

public static class Storage
{
    private static readonly JsonSerializerOptions _opt = new() { WriteIndented = true };
    public static void Save<T>(string path, T data)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var json = JsonSerializer.Serialize(data, _opt);
        File.WriteAllText(path, json);
    }

    public static T Load<T>(string path, T fallback) where T : new()
    {
        if (!File.Exists(path)) return fallback;
        try
        {
            var json = File.ReadAllText(path);
            var data = JsonSerializer.Deserialize<T>(json);
            return data is not null ? data : fallback;
        }
        catch
        {
            return fallback;
        }
    }
}