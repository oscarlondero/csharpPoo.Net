using Postulador.ConsoleApp.Domain;

namespace Postulador.ConsoleApp.Reports;

public interface IReporte
{
    string Titulo { get; }
    void Imprimir(IEnumerable<Persona> personas, IEnumerable<Especialidad> especialidades, IEnumerable<Servicio> servicios, decimal dolarVenta);
}

public class ReporteServiciosPorPersona : IReporte
{
    public string Titulo => "Servicios por Persona";
    public void Imprimir(IEnumerable<Persona> personas, IEnumerable<Especialidad> especialidades, IEnumerable<Servicio> servicios, decimal dolarVenta)
    {
        Console.WriteLine($"==== {Titulo} (USD y AR$ a venta {dolarVenta}) ====");
        foreach (var p in personas.OrderBy(x => x.Nombre))
        {
            Console.WriteLine($"
{p}");
            var svs = servicios.Where(s => s.PersonaId == p.Id).ToList();
            if (!svs.Any()) { Console.WriteLine("  (sin servicios)"); continue; }
            foreach (var s in svs)
            {
                var esp = especialidades.FirstOrDefault(e => e.Id == s.EspecialidadId);
                var pesos = s.PrecioEnPesos(dolarVenta);
                Console.WriteLine($"  - {esp?.Nombre} · {s.Descripcion} · USD {s.PrecioUSD} · AR$ {pesos}");
            }
        }
        Console.WriteLine();
    }
}

public class ReporteTarifasPromedioPorEspecialidad : IReporte
{
    public string Titulo => "Tarifas Promedio por Especialidad (en USD)";
    public void Imprimir(IEnumerable<Persona> personas, IEnumerable<Especialidad> especialidades, IEnumerable<Servicio> servicios, decimal dolarVenta)
    {
        Console.WriteLine($"==== {Titulo} ====");
        var grp = servicios
            .GroupBy(s => s.EspecialidadId)
            .Select(g => new {
                Especialidad = especialidades.FirstOrDefault(e => e.Id == g.Key)?.ToString() ?? $"Esp#{g.Key}",
                PromedioUSD = g.Average(x => x.PrecioUSD),
                Cant = g.Count()
            })
            .OrderByDescending(x => x.PromedioUSD);

        foreach (var r in grp)
            Console.WriteLine($" - {r.Especialidad}: USD {Math.Round(r.PromedioUSD,2)} (n={r.Cant})");
        Console.WriteLine();
    }
}